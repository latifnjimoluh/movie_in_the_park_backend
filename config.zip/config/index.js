const config = require("./database")
const { sequelize } = require("../src/models")

module.exports = {
  config,
  sequelize,
}
